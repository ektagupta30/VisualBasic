﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmInClassIF
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCode = New System.Windows.Forms.Label()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.lblField1 = New System.Windows.Forms.Label()
        Me.txtField1 = New System.Windows.Forms.TextBox()
        Me.lblField2 = New System.Windows.Forms.Label()
        Me.txtField2 = New System.Windows.Forms.TextBox()
        Me.lblField3 = New System.Windows.Forms.Label()
        Me.txtField3 = New System.Windows.Forms.TextBox()
        Me.btnFirst = New System.Windows.Forms.Button()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.btnSecond = New System.Windows.Forms.Button()
        Me.btnThird = New System.Windows.Forms.Button()
        Me.btnFourth = New System.Windows.Forms.Button()
        Me.btnFifth = New System.Windows.Forms.Button()
        Me.btnSixth = New System.Windows.Forms.Button()
        Me.btnSeventh = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblCode
        '
        Me.lblCode.AutoSize = True
        Me.lblCode.Location = New System.Drawing.Point(8, 18)
        Me.lblCode.Name = "lblCode"
        Me.lblCode.Size = New System.Drawing.Size(35, 13)
        Me.lblCode.TabIndex = 0
        Me.lblCode.Text = "Code:"
        '
        'txtCode
        '
        Me.txtCode.Location = New System.Drawing.Point(70, 11)
        Me.txtCode.Name = "txtCode"
        Me.txtCode.Size = New System.Drawing.Size(58, 20)
        Me.txtCode.TabIndex = 1
        '
        'lblField1
        '
        Me.lblField1.AutoSize = True
        Me.lblField1.Location = New System.Drawing.Point(76, 57)
        Me.lblField1.Name = "lblField1"
        Me.lblField1.Size = New System.Drawing.Size(41, 13)
        Me.lblField1.TabIndex = 2
        Me.lblField1.Text = "Field 1:"
        '
        'txtField1
        '
        Me.txtField1.Location = New System.Drawing.Point(154, 50)
        Me.txtField1.Name = "txtField1"
        Me.txtField1.Size = New System.Drawing.Size(55, 20)
        Me.txtField1.TabIndex = 3
        '
        'lblField2
        '
        Me.lblField2.AutoSize = True
        Me.lblField2.Location = New System.Drawing.Point(76, 86)
        Me.lblField2.Name = "lblField2"
        Me.lblField2.Size = New System.Drawing.Size(41, 13)
        Me.lblField2.TabIndex = 4
        Me.lblField2.Text = "Field 2:"
        '
        'txtField2
        '
        Me.txtField2.Location = New System.Drawing.Point(154, 81)
        Me.txtField2.Name = "txtField2"
        Me.txtField2.Size = New System.Drawing.Size(55, 20)
        Me.txtField2.TabIndex = 5
        '
        'lblField3
        '
        Me.lblField3.AutoSize = True
        Me.lblField3.Location = New System.Drawing.Point(74, 115)
        Me.lblField3.Name = "lblField3"
        Me.lblField3.Size = New System.Drawing.Size(41, 13)
        Me.lblField3.TabIndex = 6
        Me.lblField3.Text = "Field 3:"
        '
        'txtField3
        '
        Me.txtField3.Location = New System.Drawing.Point(155, 112)
        Me.txtField3.Name = "txtField3"
        Me.txtField3.Size = New System.Drawing.Size(53, 20)
        Me.txtField3.TabIndex = 7
        '
        'btnFirst
        '
        Me.btnFirst.Location = New System.Drawing.Point(11, 206)
        Me.btnFirst.Name = "btnFirst"
        Me.btnFirst.Size = New System.Drawing.Size(60, 30)
        Me.btnFirst.TabIndex = 8
        Me.btnFirst.Text = "First"
        Me.btnFirst.UseVisualStyleBackColor = True
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(37, 160)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(190, 20)
        Me.txtResult.TabIndex = 9
        '
        'btnSecond
        '
        Me.btnSecond.Location = New System.Drawing.Point(77, 206)
        Me.btnSecond.Name = "btnSecond"
        Me.btnSecond.Size = New System.Drawing.Size(60, 30)
        Me.btnSecond.TabIndex = 10
        Me.btnSecond.Text = "Second"
        Me.btnSecond.UseVisualStyleBackColor = True
        '
        'btnThird
        '
        Me.btnThird.Location = New System.Drawing.Point(143, 206)
        Me.btnThird.Name = "btnThird"
        Me.btnThird.Size = New System.Drawing.Size(60, 30)
        Me.btnThird.TabIndex = 11
        Me.btnThird.Text = "Third"
        Me.btnThird.UseVisualStyleBackColor = True
        '
        'btnFourth
        '
        Me.btnFourth.Location = New System.Drawing.Point(209, 206)
        Me.btnFourth.Name = "btnFourth"
        Me.btnFourth.Size = New System.Drawing.Size(60, 30)
        Me.btnFourth.TabIndex = 12
        Me.btnFourth.Text = "Fourth"
        Me.btnFourth.UseVisualStyleBackColor = True
        '
        'btnFifth
        '
        Me.btnFifth.Location = New System.Drawing.Point(15, 261)
        Me.btnFifth.Name = "btnFifth"
        Me.btnFifth.Size = New System.Drawing.Size(60, 30)
        Me.btnFifth.TabIndex = 13
        Me.btnFifth.Text = "Fifth"
        Me.btnFifth.UseVisualStyleBackColor = True
        '
        'btnSixth
        '
        Me.btnSixth.Location = New System.Drawing.Point(79, 261)
        Me.btnSixth.Name = "btnSixth"
        Me.btnSixth.Size = New System.Drawing.Size(60, 30)
        Me.btnSixth.TabIndex = 14
        Me.btnSixth.Text = "Sixth"
        Me.btnSixth.UseVisualStyleBackColor = True
        '
        'btnSeventh
        '
        Me.btnSeventh.Location = New System.Drawing.Point(145, 264)
        Me.btnSeventh.Name = "btnSeventh"
        Me.btnSeventh.Size = New System.Drawing.Size(57, 26)
        Me.btnSeventh.TabIndex = 15
        Me.btnSeventh.Text = "Seventh"
        Me.btnSeventh.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(52, 338)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 16
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'frmInClassIF
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 436)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnSeventh)
        Me.Controls.Add(Me.btnSixth)
        Me.Controls.Add(Me.btnFifth)
        Me.Controls.Add(Me.btnFourth)
        Me.Controls.Add(Me.btnThird)
        Me.Controls.Add(Me.btnSecond)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.btnFirst)
        Me.Controls.Add(Me.txtField3)
        Me.Controls.Add(Me.lblField3)
        Me.Controls.Add(Me.txtField2)
        Me.Controls.Add(Me.lblField2)
        Me.Controls.Add(Me.txtField1)
        Me.Controls.Add(Me.lblField1)
        Me.Controls.Add(Me.txtCode)
        Me.Controls.Add(Me.lblCode)
        Me.Name = "frmInClassIF"
        Me.Text = "In Class If"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblCode As System.Windows.Forms.Label
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents lblField1 As System.Windows.Forms.Label
    Friend WithEvents txtField1 As System.Windows.Forms.TextBox
    Friend WithEvents lblField2 As System.Windows.Forms.Label
    Friend WithEvents txtField2 As System.Windows.Forms.TextBox
    Friend WithEvents lblField3 As System.Windows.Forms.Label
    Friend WithEvents txtField3 As System.Windows.Forms.TextBox
    Friend WithEvents btnFirst As System.Windows.Forms.Button
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents btnSecond As System.Windows.Forms.Button
    Friend WithEvents btnThird As System.Windows.Forms.Button
    Friend WithEvents btnFourth As System.Windows.Forms.Button
    Friend WithEvents btnFifth As System.Windows.Forms.Button
    Friend WithEvents btnSixth As System.Windows.Forms.Button
    Friend WithEvents btnSeventh As System.Windows.Forms.Button
    Friend WithEvents btnReset As System.Windows.Forms.Button

End Class
